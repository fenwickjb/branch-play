#!/bin/sh

str="hello tim"

echo ${str:0:3}

echo ${str:(-1):3}
