#!/usr/bin/env bash
#read_input ()
# { 
if [[ ("$1" != "") ]];then
    echo "$1" | while read -r input;do
        #found_a=$(echo "$input"|awk '/a/ {print}')
        #echo "expr match "$input" 'abc[A-Z]*.a'"
        #tot_lets=$(echo "$input"|wc -c) #includes newline \n
        tot_lets=$(echo "$input"|tr -d '\n'|wc -c)
        let tot_lets-- #substr start counting a zero, so subtract 1
        # Remove newline character
        new_input=$(echo "$input"|tr -d '\n')
        #new_input=$(echo "$input"|sed -e 's/[[:space:]]*#.*// ;/^[[:space:]]*$/d')
        count_a=$(echo "$input"|tr -d -c 'a\n' | awk '{ print length; }')
        count_b=$(echo "$input"|tr -d -c 'b\n' | awk '{ print length; }')
        #sed -e :a -e '/\\$/N; s/\\\n//; ta'
        first_let=${new_input:0:1}
        second_let=${new_input:1:1}
        let "next2last_num = $tot_lets - 1"
        next2last_let=${new_input:next2last_num:1}
        echo "The next to last number is $next2last_nun and the last is $tot_lets"
        last_let=${new_input:tot_lets:1}
        #-----------------------------------------------------
        # The next two steps are checking the first and last letters
        # of the input. If the first letter is not an "a"
        # or if the last letter is an "a", then we exit
        #-----------------------------------------------------
        if [ "$last_let" == "a" ];then
            #echo "** The last letter was an a **"
            return 1 #we are done if the last letter is an "a"
        elif [ "$first_let" != "a" ];then
            # "a" has to be the first letter or we exit
            return 1
        #-----------------------------------------------------
        # If the first letter is a j, if so exit
        #-----------------------------------------------------
        elif [ "$first_let" == "j" ];then
            #echo "** The first letter was an j **"
            return 1 #we are done if the first letter is a "j"
        #-----------------------------------------------------
        # Now, using the count of actual letters from tot_lets
        # we will step through the input and count only "a"s and "b"s
        # If we find anything else, we will exclude it and keep going
        #-----------------------------------------------------
        elif [ "$first_let" == "a" ] && [ "$next2last_let" == "b" ];then
            # Remove any other characters than "a" or "b"
            new_input=$(echo "$new_input"|sed 's/[cdefghijklmnop]+/a/g')
            # Start from the front for "a"s
            # Initialize count to zero to start looking for "a"s
            count=0
            while [[ "$count" -le "$tot_lets" ]];do
                let count++
                echo "The count for a is = $count"
                next_let=${new_input:count:1}
                echo "The next letter is $next_let"
                if [ "$next_let" == "a" ];then
                    found_a="${found_a}a"
                else
                    found_a="${found_a}a"
                    break
                fi
            done
            # Initialize count to end of the list to look for "b"s
            count=$tot_lets+1
            while [[ "$count" -gt 0 ]];do
                let count--
                echo "The count for b is $count"
                next_let=${new_input:count:1}
                echo "The next letter is $next_let"
                if [ "$next_let" == "b" ];then
                    found_b="${found_b}b"
                else
                    break
                fi
            done
            #else 
            #found_not=$(echo "$input"|sed 's/[^j]//g'|awk '{print}')
            #found_a=$(echo "$new_input"|sed 's/[^a]//g'|awk '{print}')
            #found_b=$(echo "$new_input"|sed 's/[^b]//g'|awk '{print}')
            #while [ "$found_a" == "aabbb" ];do
                #let count_a++
                #echo "There are $count_a a's in the input"
            #done
            echo "The first letter is $first_let"
            echo "The last letter is $last_let"
            echo "The total number of letters is =  $tot_lets "
            echo "There are $count_a a's in the input"
            echo "There are $count_b b's in the input"
                #now we want to see if there are more 'a's in 
                #the input string, so we'll parse the line for another
            echo "The new input is $new_input"
            echo "The output of found_a is $found_a"
            echo "The output of found_b is $found_b"
            echo "$found_b X $found_a"
        else
            return 1
        fi

        #last_let=$(echo "$input" | sed -r 's/\s//g ; s/^(.{4})(.).*$/\2/')
        #count=0
        #echo "$new_input" | while IFS= read -r -n 1 char;do
            #char=$(echo "$char"|tr -d '\n')
            #echo "Char is inside the while = $char"
        #newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        
        # This commented out section would reverse the words
        # in the output so that they would read from right to left
        #sep=$(echo "$newline"|tr " " "\n")
        #echo "$sep"|while read -r input;do
        #    newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        #echo "$newline"
        #done
    done
else
    return 1
fi
# }

remove_newline ()
{
    echo "$1"|while read -r input;do
        #newline=$(echo "$input"|tr -d "\n" " ")
        newlines=$(echo "$input"|awk '{print}' ORS=' ')
        echo "$newlines"
    done
}
# Main program
#if [[ ("$1" != "") ]];then
#    newlines=$(read_input "$1")
    #test=$(remove_newline "$newlines"|sed ':a; N; $!ba; s/\n//g')
#    echo "$newlines"

#else
#    return 1
#fi
