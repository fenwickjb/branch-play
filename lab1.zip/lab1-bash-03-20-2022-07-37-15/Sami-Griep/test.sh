#!/bin/bash

if [ $# -ne 1 ]; then
 echo 1
else

for arg do
    lena=0
    lenb=0
    as=`echo $arg | grep -o '^a*'`
    bs=`echo $arg | grep -o 'b*$'`
    lena=${#as}
    lenb=${#bs}
    if (( $lena > 0 )) && (( $lenb > 0 )); then
	echo "$bs X $as"
	echo 0
    fi
    echo 1
done
fi