// Author(s): Alex Clarke
// Date:      2022-02-09
// Class:     CS5521
// Name:      Lab 03

// Based on a provided program, all changes have been marked with !!CHANGED!!.

import java.io.*;
import java.net.URL;

class Downloader extends Thread {
  // File Manager provides the downloader with the attributes of the next file
  // to download.
  private FileManager fm;
  // Download file chunkSize bytes at a time.
  private final int chunkSize = 1024;

  // !!CHANGED!! - A value to keep track of which thread this is.
  private int threadNum;

  // Constructor.
  Downloader(FileManager fm, int threadNum) {
    this.fm = fm;
    // !!CHANGED!! - Set the thread number.
    this.threadNum = threadNum;
  }

  // Get the attributes of files to download and download them.
  // !!CHANGED!! - Change doDownloads to run.
  public void run() {
    // Get attributes of next file from File Manager.
    FileAttributes fileAttrs = fm.getNextFile();
    while (fileAttrs != null) {
      // CHANGED - Set the thread number in the current the file attributes.
      fileAttrs.updateThread(threadNum);
      // Go the download.
      downloadFile(fileAttrs);
      fileAttrs = fm.getNextFile();
    }
  }

  public void downloadFile(FileAttributes fileAttrs) {
    // Attributes of the file include the url, the filename to be used for the
    // destination, and the download directory.
    String fileURL = fileAttrs.getFilePath();
    String fileName = fileAttrs.getFileName();
    String downloadDir = fileAttrs.getDownloadDir();
    String destination = downloadDir + "/" + fileName;

    // Download the object at the URL.
    // Store it in the destination.
    try (BufferedInputStream in = new 
    BufferedInputStream(new URL(fileURL).openStream());
    FileOutputStream fileOutputStream = new FileOutputStream(destination)) {
      // Download in chunks of chunkSize bytes at a time.
      byte dataBuffer[] = new byte[chunkSize];
      int bytesRead;
      while ((bytesRead = in.read(dataBuffer, 0, chunkSize)) != -1) {
        // Write the chunk read to the destination.
        fileOutputStream.write(dataBuffer, 0, bytesRead);
        // Update the downloaded amount that is maintained in the File
        // Attributes.
        fileAttrs.updateDownload(bytesRead);
        // Update the total download amount that is maintained by the File
        // Manager.
        fm.updateTotalDownload(bytesRead);
      }
    } catch (IOException e) {
      System.out.println("Unable to read " + fileURL);
    }
  }
}