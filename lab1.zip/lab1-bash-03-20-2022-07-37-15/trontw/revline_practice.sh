#!/usr/bin/env bash
reverse_words ()
{
    echo "$1" | while read -r input;do
        newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        # This commented out section would reverse the words
        # in the output so that they would read from right to left
        #sep=$(echo "$newline"|tr " " "\n")
        #echo "$sep"|while read -r input;do
        #    newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        echo "$newline"
        #done
    done
}

remove_newline ()
{
    echo "$1"|while read -r input;do
        #newline=$(echo "$input"|tr -d "\n" " ")
        newlines=$(echo "$input"|awk '{print}' ORS=' ')
        echo "$newlines"
    done
}
# Main program
if [[ ("$1" != "") ]];then
    newlines=$(reverse_words "$1")
    test=$(remove_newline "$newlines"|sed ':a; N; $!ba; s/\n//g')
    echo "$test"

else
    return 1
fi