//package com.journaldev.threadpool;

import java.io.*;
import java.net.URL;

//class implements the Runnable interface, each Downloader will be a thread executed
//by the thread pool Executor
class Downloader implements Runnable 
{
    //File Manager provides the downloader with the
    //attributes of the next file to download
    private FileManager fm;
    //download file chunkSize bytes at a time
    private final int chunkSize = 1024;

    //constructor
    Downloader(FileManager fm)
    {
       this.fm = fm;
    }
    
    @Override
    //run method needs to be implemented to implement the runnable interface
    //when a Downloader thread is executed this method will be called
    public void run() {
        try { 
            doDownloads();
            //System.out.println("Thread " + Thread.currentThread().getId() + " is running");   
        } catch (Exception e) {
            System.out.println("exception caught");
        }
    }

    //get the attributes of files to download and download them.
    public void doDownloads()
    {
       //get attributes of next file from File Manager
       FileAttributes fileAttrs = fm.getNextFile();
       while (fileAttrs != null)
       {
           //go the download
           downloadFile(fileAttrs);
           fileAttrs = fm.getNextFile();
       }
    }
    
    //method is synchronized so that only one thread or Downloader is trying to 
    //download or access one file at a time    
    public synchronized void downloadFile(FileAttributes fileAttrs)
    {
        //attributes of the file include the url, the filename to be used
        //for the destination, and the download directory 
        String fileURL = fileAttrs.getFilePath();
        String fileName = fileAttrs.getFileName();
        String downloadDir = fileAttrs.getDownloadDir();
        String destination = downloadDir + "/" + fileName;
        //set Thread name associated with a file to the current Thread's id number
        fileAttrs.setThreadName(Thread.currentThread().getId());

        //download the object at the URL
        //store it in the destination
        try (BufferedInputStream in = new 
            BufferedInputStream(new URL(fileURL).openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(destination)) 
        {
            //download in chunks of chunkSize bytes at a time
            byte dataBuffer[] = new byte[chunkSize];
            int bytesRead;
            int iterations = 0;
            while ((bytesRead = in.read(dataBuffer, 0, chunkSize)) != -1) 
            {
                //write the chunk read to the destination
                fileOutputStream.write(dataBuffer, 0, bytesRead);
                //update the downloaded amount that is maintained in the File Attributes
                fileAttrs.updateDownload(bytesRead);
                //update the total download amount that is maintained by the File Manager
                fm.updateTotalDownload(bytesRead);
                if (iterations % 1000 == 0)
                    fm.printUpdate();
                iterations++; 
            }
        } catch (IOException e) 
        {
            System.out.println("Unable to read " + fileURL);
        }
    }
}
