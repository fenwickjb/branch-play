#!/bin/bash

switch() {
  if [[ -z "$1" ]]; then
      echo "no param"
      return 1
    else
      var="$1"
      first="${var:0:3}"
      last="${var:(-3)}"
      rest="${var:3:(-3)}"
      echo "$last$rest$first"
      return 0
    fi
}

switch "hi there"