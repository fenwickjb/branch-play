
// All lexers must implement the "next token" function!

public interface Lexer {
    int yylex();
}
