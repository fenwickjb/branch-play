# lab4-javathreads-qcorcoran
lab4-javathreads-qcorcoran created by GitHub Classroom

Multithreaded Downloader

usage: java Grab <download directory> [threadCount | clean]
       if clean option given, stop after deleting
       download directory and contents concurrently.
