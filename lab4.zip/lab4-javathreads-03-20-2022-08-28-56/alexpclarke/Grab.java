// Author(s): Alex Clarke
// Date:      2022-02-09
// Class:     CS5521
// Name:      Lab 03

// Based on a provided program, all changes have been marked with !!CHANGED!!.

import java.io.File;
import java.lang.*;

// Driver class for downloading files.
class Grab {
  // True if only cleaning up a downloads directory.
  boolean cleanOnly;
  //destination directory for the downloads.
  String downloadDir;

  // !!CHANGED!! - Value to store the number of threads requested.
  int numThreads;

  // Control starts here.
  public static void main(String args[]) {
    // Calculate the time it takes to perform the download.
    long startTime = System.currentTimeMillis();

    // Parse command line arguments and create a Grab object.
    Grab grabber = new Grab(args);
    // Download all of the files.
    grabber.grabFiles();

    // Report the amount of time it took to do all of the downloads.
    long endTime = System.currentTimeMillis();
    System.out.println("Total execution time (ms): " + (endTime - startTime));
  }

  // Constructor.
  Grab(String args[]) {
    // Program executed in one of these ways:
    // java Grab Downloads - Download the files and put them in the Downloads
    //   directory (creating the directory first; deleting old directory if 
    //   necessary).
    // java Grab Downloads clean - Delete Downloads directory and stop.

    // Clear cleanOnly.
    cleanOnly = false;

    // !!CHANGED!! - Clear numThreads.
    numThreads = 1;
    
    // Make sure we have enough arguments.
    if (args.length < 1) printUsage();

    // Don't let the downloads directory be named clean.
    if (args[0].equals("clean")) {
      System.out.println("error: provide the name of the downloads directory.");
      printUsage();
    }

    // Set the download directory to the first argument.
    downloadDir = args[0];

    // !!CHANGED!! - Parse the number of threads and print usage if there is an
    // error.
    if (args.length > 1) {
      try {
        numThreads = Integer.parseInt(args[1]);
      } catch(NumberFormatException nFE) {
        System.out.println("error: number of threads must be an integer greater"
          + "than 0.");
        printUsage();
      }
    }
    
    if (args.length > 1 && args[1].equals("clean")) cleanOnly = true;
  }

  // Use a FileManager object and a Downloader object to do the actual download.
  public void grabFiles() {
    // Delete old downloads directory and create a new one nless program is only
    // performing a clean
    cleanUp(downloadDir);

    if (cleanOnly == false) {
      // FileManager object provides the attributes of each file to download.
      FileManager fm = new FileManager(downloadDir);

      // !!CHANGED!! - Create an array of Downloader threads and start them.
      Downloader thread[] = new Downloader[numThreads];
      for (int i = 0; i < numThreads; i++) {
        thread[i] = new Downloader(fm, i);
        thread[i].start();
      }

      // !!CHANGED!! - While there are still some threads alive, print the out
      // the progress every 1 second.
      int i = 0;
      while (i < numThreads) {
        fm.printUpdate();
        try {Thread.sleep(1000);}
        catch(Exception ex) {}
        if (!thread[i].isAlive()) i++;
      }
      
      // Print the result of the download.
      fm.printFinal();
    } else {
      // If clean option used, print message and exit.
      System.out.println("Removed directory " + downloadDir);
      System.exit(0);
    }
  }

  // Print usage information.
  // !!CHANGED!! - Updated the output of printUsage.
  public void printUsage() {
    System.out.println("usage: java Download <download directory> [clean "
      + "| threads]");
    System.out.println("       if clean option given, stop after deleting");
    System.out.println("       download directory and contents.");
    System.out.println("       If no thread is given, use 1 thread.");
    System.exit(0);
  }

  // Delete and old downloads directory and create a new one if a download is to
  // be performed.
  public void cleanUp(String downloadDir) {
    File dir = new File(downloadDir);
    // If the download directory exists, perform a recursive delete on it and
    // its contents.
    if (dir.exists()) deleteDirectory(dir);
      
    try {
      // If not simply deleting the downloads directory, create a new one.
      if (cleanOnly == false) {
        dir.mkdir();
        if (!dir.exists()) badDirectory();
      }
    } catch (Exception e) {
      badDirectory();
    }
  }
   
  // Called when program is not able to create downloads directory.
  private void badDirectory() {
    System.out.println("error: unable to create download directory: "
      + downloadDir);
    printUsage(); 
  }

  // Perform a recursive delete of the contents of a directory.
  private boolean deleteDirectory(File file) {
    // If the file is a directory, delete contents first.
    if (file.isDirectory()) {
      // Get the files in the directory.
      File[] children = file.listFiles();
      for (int i = 0; i < children.length; i++) {
        // Call deleteDirectory on each child.
        boolean success = deleteDirectory(children[i]);
        if (!success) return false;
      }
    }
    // Delete the file or empty directory.
    return file.delete();
  }
}