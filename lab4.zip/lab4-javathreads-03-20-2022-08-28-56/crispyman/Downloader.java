import java.io.*;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;

import static java.lang.Thread.sleep;

class Downloader{
    //File Manager provides the downloader with the
    //attributes of the next file to download
    private FileManager fm;
    //download file chunkSize bytes at a time
    private final int chunkSize = 1024;
    //max allowed threads
    private int threads;

    //constructor
    Downloader(FileManager fm, int threads) {
        this.fm = fm;
        this.threads = threads;
    }

    //get the attributes of files to download and download them.
    public void doDownloads() throws InterruptedException {
        // creates a pool of size this.threads which is passed in with the constructor.
        // also used to make it easy to call stop on threads without an array of them
        ExecutorService pool = Executors.newFixedThreadPool(this.threads);
        //temp variable to let us add threads to our pool without nesting even more parenthesis.
        Thread t;
        //launches the correct number of threads for the value of this.threads
        for (int i =0; i < this.threads; i++) {
            //Spawns instance of function as thread
            t = new Thread(this::downloadFile, Integer.toString(i));
            //System.out.println(Integer.toString(i));
            //executes above thread in thread pool, will queue up threads in excess of this.threads value
            pool.execute(t);
            //t.setName(Integer.toString(i));


        }
        //tells the pool it needs to shut down all its threads
        pool.shutdown();

        // print update prints finished Downloads and returns true when it's
        // done printing everything. sleep is in millis so 1000 is 1 second.
        while(!fm.printUpdate())
            sleep(1000);
    }


    public void downloadFile()
    {
        //attributes of the file include the url, the filename to be used
        //for the destination, and the download directory
        FileAttributes fileAttrs;
        //we use synchronized to ensure that we don't have a race condition when accessing the file array.
        synchronized (fm) {
            fileAttrs = fm.getNextFile();
        }
        while (fileAttrs != null) {

            //ensures that we don't have two threads working on the same download
            //or skip a thread by only letting us get one file at a time between threads.

            String fileURL = fileAttrs.getFilePath();
            String fileName = fileAttrs.getFileName();
            String downloadDir = fileAttrs.getDownloadDir();
            String destination = downloadDir + "/" + fileName;


            //download the object at the URL
            //store it in the destination
            try (BufferedInputStream in = new
                    BufferedInputStream(new URL(fileURL).openStream());
                 FileOutputStream fileOutputStream = new FileOutputStream(destination)) {
                //download in chunks of chunkSize bytes at a time
                byte dataBuffer[] = new byte[chunkSize];
                int bytesRead;
                while ((bytesRead = in.read(dataBuffer, 0, chunkSize)) != -1) {
                    //write the chunk read to the destination
                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                    //update the downloaded amount that is maintained in the File Attributes
                    fileAttrs.updateDownload(bytesRead);

                    //update the total download amount that is maintained by the File Manager
                    //it needs to be synchronized so that multiple threads don't try to modify
                    //the total download variable at the same time and enter a race condition
                    //you could make totalDownload atomic instead, and it would be more performant.
                    //switched to an atomic variable, it caused a noticeable improvement in performance
                    fm.updateTotalDownload(bytesRead);

                }
                // lets the main thread know that this thread is done downloading the file
                // does not need to be atomic because we are only checking the variable in one place
            } catch (IOException e) {
                System.out.println("Unable to read " + fileURL);
            }
            /*System.out.println(Thread.currentThread().getName());
            A kinda hack to get the thread number back to the main thread, it's been made worse by my code to set
            the thread number not really working for unknown reasons.
            The set operation is safe however because certain operations are guaranteed to be atomic in java on certain
            primitives, in the case of int setting and reading an object, but not any operation that does both.
            also, since only this thread and the main thread operate on the variable, and the main thread waits for
            this thread to change the value before doing anything, we can be certain that there will not be a race
            condition. This assumes that multiple threads are not processing the same file but that's a problem
            for code elsewhere in this file to deal with.
             */
            fileAttrs.setDone(Integer.parseInt(Thread.currentThread().getName().split("-")[3])-1);

            // Since we have a shared object that is not thread safe (fm) we need to access it with synchronized
            synchronized (fm) {
                fileAttrs = fm.getNextFile();
            }
        }
    }
}
