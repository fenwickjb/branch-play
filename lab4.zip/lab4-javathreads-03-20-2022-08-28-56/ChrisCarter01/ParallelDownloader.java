import java.io.*;
import java.net.URL;

class ParallelDownloader extends Thread
{
    //File Manager provides the downloader with the
    //attributes of the next file to download
    private FileManager fm;
    //download file chunkSize bytes at a time
    private final int chunkSize = 1024;

    //constructor
    ParallelDownloader(FileManager fm)
    {
       this.fm = fm;
    }

    /**
     * Perform the running loop for this thread, calling doNextDownload until it returns false,
     * and then updating the output string with the proper values. 
     */
    @Override
    public void run() {
    	//Call doNextDownload in a loop until there are no more files to download (it returns false).
    	while(doNextDownload()) {
    		//This while block is empty, which I feel like is somehow bad practice, so
    		//I'm putting this comment here to make me feel better about it.
    	}
    	
    	//Befoe the thread terminates, decrement the number of threads in the fileManager.
    	fm.decrementThreadCount();
    }
    
    /**
     * Do the next download that the FileManager has in the queue and return true.
     * If no such files exist, return false.
     */
    public boolean doNextDownload() {
    	//get the file from the synchronized method in file manager
    	FileAttributes fileAttrs = fm.getNextFile();
    	//If there are no more files to download, return false.
    	if(fileAttrs == null) return false;
    	
    	//If there is another file to download, Notify that file attribute that it is being run.
    	fileAttrs.setThread(this);
    	
    	//Download the file described in the file attribute object.
    	downloadFile(fileAttrs);
    	
    	//Return true to signify that this thread is still working.
    	return true;
    }
    
    //get the attributes of files to download and download them.
    @Deprecated
    public void doDownloads()
    {
       //get attributes of next file from File Manager
       FileAttributes fileAttrs = fm.getNextFile();
       while (fileAttrs != null)
       {
           //go the download
           downloadFile(fileAttrs);
           fileAttrs = fm.getNextFile();
       }
    }
    
    public void downloadFile(FileAttributes fileAttrs)
    {
        //attributes of the file include the url, the filename to be used
        //for the destination, and the download directory 
        String fileURL = fileAttrs.getFilePath();
        String fileName = fileAttrs.getFileName();
        String downloadDir = fileAttrs.getDownloadDir();
        String destination = downloadDir + "/" + fileName;

        //download the object at the URL
        //store it in the destination
        try (BufferedInputStream in = new 
            BufferedInputStream(new URL(fileURL).openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(destination)) 
        {
            //download in chunks of chunkSize bytes at a time
            byte dataBuffer[] = new byte[chunkSize];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, chunkSize)) != -1) 
            {
                //write the chunk read to the destination
                fileOutputStream.write(dataBuffer, 0, bytesRead);
                //update the downloaded amount that is maintained in the File Attributes
                //Since the only point of access for the File Attribute is already syncronized, we won't
                //won't need to implement any syncronized functions for that class.
                fileAttrs.updateDownload(bytesRead);
                
                //update the total download amount that is maintained by the File Manager
                fm.updateTotalDownload(bytesRead);
                
            }
            
            //fm.notifyMainThread(this, fileAttrs);

        } catch (IOException e) 
        {
            System.out.println("Unable to read " + fileURL);
        }
    }
}
