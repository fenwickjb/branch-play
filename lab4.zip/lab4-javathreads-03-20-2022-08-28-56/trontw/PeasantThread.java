public class PeasantThread extends Thread {
    @Override
    public void run(){
        //this is what will run concurrently
        //Practice
        for (int i = 1; i <=5; i++){
            System.out.println("Hello");
            try { 
                Thread.sleep(1000);
            } catch (InterruptedException e){}
        }
      
    }
}