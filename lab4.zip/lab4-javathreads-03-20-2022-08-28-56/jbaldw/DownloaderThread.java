public class DownloaderThread implements Runnable
{
    private static int threadCount; // Keeps track of requested number of threads

    private String threadName; // Thread name/number for output 
    private Downloader downloader; // Downloader belonging to specific thread

    public DownloaderThread(String threadName, Downloader downloader)
    {
        this.threadName = threadName;
        this.downloader = (Downloader)downloader.clone();

        this.downloader.setCurrentThreadName(threadName);
    }

    public void run()
    {
        this.downloader.doDownloads();
    }

    public static int getThreadCount()
    {
        return threadCount;
    }

    public static void setThreadCount(int tc)
    {
        if(threadCount == 0)
        {
            threadCount = tc;
        }
        else
        {
            System.out.println("Can't set threadCount twice");
        }
    }
}
