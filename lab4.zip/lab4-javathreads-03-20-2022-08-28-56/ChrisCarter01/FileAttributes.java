
class FileAttributes
{
    private String filePath;        //URL
    private String downloadDir;     //destination download directory
    private String fileName;        //destination file
    private long downloadAmt;       //amount downloaded
    
    /**
     * Keep track of which thread is working on this file attribute.
     */
    private ParallelDownloader runningThread;

    //constructor
    FileAttributes(String filePath, String downloadDir)
    {
        this.downloadDir = downloadDir;  
        this.downloadAmt = 0;
        this.filePath = filePath;
        this.fileName = initFileName(filePath);
        this.runningThread = null;
    }

    //strip off the piece after the right most / and use that
    //as the filename
    private String initFileName(String path)
    {
        String[] tokens = path.split("/");
        int index = tokens.length - 1;
        if (index < 0) return null;
        if (tokens[index] == "") index--;
        if (index < 0) return null;
        return tokens[index];
    }

    //called by Downloader object to update the current
    //amount downloaded
    public void updateDownload(long amount)
    {
        this.downloadAmt += amount;
    }

    //return the file name
    public String getFileName()
    {
        return fileName;
    }

    //return the url
    public String getFilePath()
    {
        return filePath;
    }

    //return the destination download directory
    public String getDownloadDir()
    {
        return downloadDir;
    }

    //return the downloaded amount
    public long getDownloadAmount()
    {
        return downloadAmt;
    }
    
    /**
     * @return The thread running this download. Will be null until SetThread is called.
     */
    public ParallelDownloader getThread() { return runningThread; }
    /**
     * Assign a thread to this file.
     * If this file is already assigned to a thread, then an exception will be generated.
     * @param _thread The thread that this has been assigned to.
     */
    public void setThread(ParallelDownloader _thread) {
    	//Check current value of running thread.
    	if(runningThread != null) {
    		//If it is already running (Or has been run) then print an exception and exit.
    		
    		//Generate the message for the exception.
    		String eMessage = String.format("A Thread tried to claim a File Attribute that has already been assigned\n" + 
    				"\tThread (%l) tried to claim the attribute for %s, but"
    				+ "\tThread (%l) already claimed it.\n",
    				_thread.getId(), filePath, runningThread.getId());
    		Exception e = new Exception(eMessage);
    		e.printStackTrace();
    		System.exit(0);
    	}
    	
    	runningThread = _thread; 
    } 
}
