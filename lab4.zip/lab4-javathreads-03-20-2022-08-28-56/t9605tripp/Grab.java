import java.io.File;
import java.lang.*;
import java.util.concurrent.*;
//Tyler Tripp SP 2022
//driver class for downloading files
//
//Everything works as I expect, except
//sometimes the print statement shows 0 but it downloaded everything.
class Grab
{
    boolean cleanOnly;   //true if only cleaning up a downloads directory
    String downloadDir;  //destination directory for the downloads
    int numThreads;
    //control starts here
    //it might throw thread interrupts
    public static void main(String args[]) throws InterruptedException
    {
        //calculate the time it takes to perform the download
        long startTime = System.currentTimeMillis();

        //parse command line arguments and create a Grab object
        Grab grabber = new Grab(args);
        //download all of the files
        grabber.grabFiles();

        //report the amount of time it took to do all of the downloads
        long endTime = System.currentTimeMillis();
        System.out.println("Total execution time (ms): " + 
                           (endTime - startTime));
    }

    //constructor
    Grab(String args[])
    {
        //program executed in one of these ways:
        //java Grab Downloads - download the files and put them in the 
        //                      Downloads directory (creating the directory
        //                      first; deleting old directory if necessary)
        //                      (one thread)
        //java Grab Downloads X - X indicates # of threads to use.
        //java Grab Downloads clean - delete Downloads directory and stop
        cleanOnly = false;
        if (args.length < 1) printUsage();
        if (args[0].equals("clean")) 
        {
            //don't let the downloads directory be named clean
            System.out.println("error: provide the name of the downloads directory.");
            printUsage();
        }
        downloadDir = args[0];

        //If there is a threads arg then parse it to get #threads
        if (args.length > 1){
            
            //System.out.println(" 0: " + args[0] + " 1: " + args[1]);
            
            //parse string indicating #of threads to int or clean
            if (args[1].equals("clean")){
                cleanOnly = true;
            } else {
                numThreads = Integer.parseInt(args[1]);
            }
        } else {
            //if no thread option selected, just use one
            numThreads = 1;
        }
    }

    //use a FileManager object and a Downloader object to do the actual
    //download
    public void grabFiles()
    {
        //delete old downloads directory and create a new one
        //unless program is only performing a clean
        cleanUp(downloadDir);
        if (cleanOnly == false)
        {
         
            //FileManager object provides the attributes of each file to download
            FileManager fm = new FileManager(downloadDir);
            //Downloader object performs the downloads, getting the attributes of
            //each file from the FileManager
            //
            //System.out.println("Threads Requested: " + numThreads);
            //
            //Make the threads here and start them!
            Thread threads[] = new Thread[numThreads]; 
            for (int i = 0; i < numThreads; i++){
                
                //System.out.println("Making thread: " + i);
                
                threads[i] = new Thread(new Downloader(fm, i));
                threads[i].start();
            }
            

            //Old Serial code
            //Downloader dl = new Downloader(fm);
            //dl.doDownloads();
            

            //print status periodically. 
            long start = System.currentTimeMillis();
            long curr = System.currentTimeMillis();
            //threads[0] will be the "main thread".
            //If it is alive, then print update periodically
            while (threads[0].isAlive()){
                if (curr - start >= 10){
                    fm.printUpdate();
                    start = System.currentTimeMillis();
                }
                curr = System.currentTimeMillis();
            }
            //print the last update.
            fm.printUpdate();
        } else {
            //if clean option used, print message and exit
            System.out.println("Removed directory " + downloadDir);
            System.exit(0);
        }

    }

    //print usage information
/* ****************************** THIS TO INCLUDE SPECIFYING THREADS********************************/
    public void printUsage()
    {
        System.out.println("usage: java Download <download directory> [clean]");
        System.out.println("       if clean option given, stop after deleting");
        System.out.println("       download directory and contents.");
        System.exit(0);
    }


    //delete and old downloads directory and create a new one
    //if a download is to be performed
    public void cleanUp(String downloadDir)
    {
        File dir = new File(downloadDir);
        if (dir.exists())
        {
            //perform a recursive delete of the directory and its contents
            deleteDirectory(dir);
        }
        try
        {
            //if not simply deleting the downloads directory, create a new one
            if (cleanOnly == false)
            {
                dir.mkdir();
                if (!dir.exists()) badDirectory();
            }
        } catch (Exception e)
        {
            badDirectory();
        }
    }
   
    //called when program is not able to create downloads directory
    private void badDirectory()
    {
        System.out.println("error: unable to create download directory: " 
                           + downloadDir);
        printUsage(); 
    }

    //perform a recursive delete of the contents of a directory
    private boolean deleteDirectory(File file) 
    {
        //if the file is a directory, delete contents first
        if (file.isDirectory()) 
        {
            //get the files in the directory
            File[] children = file.listFiles();
            for (int i = 0; i < children.length; i++) 
            {
                //call deleteDirectory on each child
                boolean success = deleteDirectory(children[i]);
                if (!success) return false;
            }
        }
        //delete the file or empty directory
        return file.delete();
    }
}
