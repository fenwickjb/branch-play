#!/usr/bin/env bash
#read_input ()
# { 
if [[ ("$1" != "") ]];then
    echo "$1" | while read -r input;do
        #found_a=$(echo "$input"|awk '/a/ {print}')
        #echo "expr match "$input" 'abc[A-Z]*.a'"
        count_a=$(echo "$input"|tr -d -c 'a\n' | awk '{ print length; }')
        count_b=$(echo "$input"|tr -d -c 'b\n' | awk '{ print length; }')
        #sed -e :a -e '/\\$/N; s/\\\n//; ta'
        count=0
        echo "$input" | while read -r -n 1 line;do
            # If the first character is not an a or b, then quit
            if [ "$line" != "a" ] && [ "$line" != "b" ];then
                echo "Input is not a or b"
                echo "The character is = $line"
                return 1
            fi
            # Prepare to start counting a's
            echo "The count at this point is = $count"
            # Check to see if the first letter is an a
            if [[ "$line" == "a" ]] && [[ $count -eq 0 ]];then
                let "count++"
                output="a"
                echo "The first letter WAS an a"
            else
                echo "This letter was not an a"
            fi
            # Check to see if the second letter is an a
            if [[ "$line" == "a" ]] && [[ "$count" -eq 1 ]];then
                let "count++"
                output="${output}a"
                echo "The second letter was also an a"
            else
                echo "Next letter is not an a."
            fi
            if [[ "$line" == "a" ]] && [[ "$count" -ge 2 ]];then
                let "count++"
                output="${output}a"
                echo "The third letter was also an a"
            else
                echo "Next letter is not an a."
            fi
            if [[] "$line" == "b" ]] && [[] "$count" -ge 1 ]];then
                let "count++"
                output="${output}b"
                echo "*** The output should now be $output"
                echo "The second letter was b"
            else
                echo "Next letter is NOT b."
            fi
            echo "Inside while loop"
            echo "The output of output is $output"
        done
        found_not=$(echo "$input"|sed 's/[^j]//g'|awk '{print}')
        found_a=$(echo "$input"|sed 's/[^a]//g'|awk '{print}')
        found_b=$(echo "$input"|sed 's/[^b]//g'|awk '{print}')
        #while [ "$found_a" == "aabbb" ];do
            #let count_a++
            #echo "There are $count_a a's in the input"
        #done
        echo "There are $count_a a's in the input"
        echo "There are $count_b b's in the input"
            #now we want to see if there are more 'a's in 
            #the input string, so we'll parse the line for another
        echo "The input is $input"
        echo "The output of found_a is $found_a"
        echo "The output of found_b is $found_b"
        if [[ "$found_not" != "j" ]];then
            echo "$found_b X $found_a"
        else
            return 1
        fi
        #newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        
        # This commented out section would reverse the words
        # in the output so that they would read from right to left
        #sep=$(echo "$newline"|tr " " "\n")
        #echo "$sep"|while read -r input;do
        #    newline=$(echo "$input"|awk -vFS= '{do printf $(NF);while(--NF>0);print ""}')
        #echo "$newline"
        #done
    done
else
    return 1
fi
# }

remove_newline ()
{
    echo "$1"|while read -r input;do
        #newline=$(echo "$input"|tr -d "\n" " ")
        newlines=$(echo "$input"|awk '{print}' ORS=' ')
        echo "$newlines"
    done
}
# Main program
#if [[ ("$1" != "") ]];then
#    newlines=$(read_input "$1")
    #test=$(remove_newline "$newlines"|sed ':a; N; $!ba; s/\n//g')
#    echo "$newlines"

#else
#    return 1
#fi