
public class Multithreading {
    public static void main (String[] args){

        PeasantThread myThing1 = new PeasantThread();
        PeasantThread2 myThing2 = new PeasantThread2();

        myThing1.start();
        try { Thread.sleep(10);} catch (InterruptedException e){}
        myThing2.start();
    }
}