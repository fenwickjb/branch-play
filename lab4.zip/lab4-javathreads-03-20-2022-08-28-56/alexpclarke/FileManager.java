// Author(s): Alex Clarke
// Date:      2022-02-09
// Class:     CS5521
// Name:      Lab 03

// Based on a provided program, all changes have been marked with !!CHANGED!!.

class FileManager {
  //These are the objects to download
  private String[] urls = {
    "https://alvinalexander.com/java/java-string-array-reference-java-5-for-loop-syntax",
    "https://www.crimesceneinvestigatoredu.org/what-is-forensic-science/",
    "http://www.stewartonbibleschool.org.uk/bible/text/levit.txt",
    "http://shakespeare.mit.edu/richardiii/full.html",
    "https://www.tutorialspoint.com/java/java_multithreading.htm",
    "http://textfiles.com/etext/AUTHORS/SHAKESPEARE/shakespeare-coriolanus-24.txt",
    "https://archive.org/stream/warandpeace030164mbp/warandpeace030164mbp_djvu.txt",
    "https://covid.cdc.gov/covid-data-tracker/",
    "https://www.pcgamer.com/best-gaming-pc/",
    "http://textfiles.com/etext/AUTHORS/SHAKESPEARE/shakespeare-tragedy-58.txt",
    "http://www.stewartonbibleschool.org.uk/bible/text/genesis.txt",
    "http://triggs.djvu.org/djvu-editions.com/SHAKESPEARE/SONNETS/Download.pdf",
    "https://www.folgerdigitaltexts.org/download/pdf/Son.pdf",
    "http://shakespeare.mit.edu/merry_wives/full.html"
  };

  // All files up to next have already been downloaded.
  private int next;
  // Total amount downloaded (all files).
  private int totalDownload;
  // Attributes of each file.
  private FileAttributes[] fileAttrsArr;

  // Create a FileManager object.
  // downloadDir is the destination directory for the downloads.
  FileManager(String downLoadDir) {
    int i;
    int size = urls.length;
    // Create a FileAttributes object for each file.
    fileAttrsArr = new FileAttributes[size];
    for (i = 0; i < size; i++)
      fileAttrsArr[i] = new FileAttributes(urls[i], downLoadDir);
    // Next is the next file to download (initialize to 0).
    next = 0;
    // totalDownload is the total amount downloaded (all files).
    totalDownload = 0;
  }

  // Return the attributes of the next file to download or null if all files
  // have been downloaded.
  // !!CHANGED!! - Changed getNextFile to synchronized so that multiple threads
  // can access it without race conditions.
  public synchronized FileAttributes getNextFile() {
    if (next == fileAttrsArr.length) return null;
    next++;
    return (fileAttrsArr[next - 1]);
  }

  // Update the total download amount (all files).
  // !!CHANGED!! - Changed updateTotalDownload to synchronized so that multiple
  // threads can access it without race conditions.
  public synchronized void updateTotalDownload(int amount) {
    totalDownload += amount;
  }

  // Print an update of how much of each file has been downloaded
  // !!CHANGED!! - Added a function that will clear the screen and print the the
  // files, which thread is handling them, and their download progress.
  public void printUpdate() {
    System.out.print("\033[H\033[2J");
    for (int i = 0; i < fileAttrsArr.length; i++) {
      Integer t = fileAttrsArr[i].getThread();
      if (t == null) System.out.print("(No Thread) ");
      else System.out.print("(Thread" + t + ") ");
      System.out.println(fileAttrsArr[i].getFileName() + ": "
        + fileAttrsArr[i].getDownloadAmount());
    }
  }

  // Print an update of how much of each file has been downloaded.
  // !!CHANGED!! - Renamed printUpdate to printFinal.
  public void printFinal() {
    int i;
    System.out.print("\033[H\033[2J");
    for (i = 0; i < fileAttrsArr.length; i++) {
      System.out.println(fileAttrsArr[i].getFileName() + ": " +
        fileAttrsArr[i].getDownloadAmount());
    }
    System.out.println("Total download: " + totalDownload);
  }
}