import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.*;

//driver class for downloading files
class Grab
{
    private static int threadCount = 1;

    boolean cleanOnly;   //true if only cleaning up a downloads directory
    String downloadDir;  //destination directory for the downloads

    //control starts here
    public static void main(String args[]) throws InterruptedException // Another thread doesn't cause the interrupt so no need to catch exception, still needed for compiling
    {
        //calculate the time it takes to perform the download
        long startTime = System.currentTimeMillis();

        //parse command line arguments and create a Grab object
        Grab grabber = new Grab(args);
        //download all of the files
        grabber.grabFiles();

        //report the amount of time it took to do all of the downloads
        long endTime = System.currentTimeMillis();
        System.out.println("Total execution time (ms): " + 
                           (endTime - startTime));
    }

    //constructor
    Grab(String args[])
    {
        //program executed in one of these ways:
        //java Grab Downloads - download the files and put them in the 
        //                      Downloads directory (creating the directory
        //                      first; deleting old directory if necessary)
        //java Grab Downloads clean - delete Downloads directory and stop
        cleanOnly = false;
        if (args.length < 1) printUsage();
        if (args[0].equals("clean")) 
        {
            //don't let the downloads directory be named clean
            System.out.println("error: provide the name of the downloads directory.");
            printUsage();
        }
        downloadDir = args[0];

        if (args.length > 1 && args[1].equals("clean")) 
        {
            cleanOnly = true;
        }
        else if(args.length > 1) // Capturing number of threads, defaults to 1 if no argument
        {
            try
            {
                threadCount = Integer.parseInt(args[1]);
            }
            catch(NumberFormatException e)
            {
                printUsage();
            }
        }
    }

    //use a FileManager object and a Downloader object to do the actual
    //download
    public void grabFiles() throws InterruptedException // Propagating exception to main
    {
        //delete old downloads directory and create a new one
        //unless program is only performing a clean
        cleanUp(downloadDir);
        if (cleanOnly == false)
        {
         
            //FileManager object provides the attributes of each file to download
            FileManager fm = new FileManager(downloadDir);
            //Downloader object performs the downloads, getting the attributes of
            //each file from the FileManager
            Downloader dl = new Downloader(fm);

            ExecutorService es = Executors.newFixedThreadPool(threadCount); // Creating thread pool based on number entered at command line
            List<Future<?>> futures = new ArrayList<>(); // Creating list of futures to determine when threads complete

            // Creating new threads and submitting them to ExecutorService and capturing result in Future list
            for(int i = 0; i < threadCount; i++)
            {
                futures.add(es.submit(new DownloaderThread("Thread" + i, dl)));
            }

            // Checking if the future have completed
            while(!isDone(futures))
            {
                Thread.sleep(1000);
                fm.printUpdate(); // Printing current output
            }
            
            es.shutdown(); // Shutdown ExecutorService when all threads complete so main thread doesn't hang    
        } else
        {
            //if clean option used, print message and exit
            System.out.println("Removed directory " + downloadDir);
            System.exit(0);
        }

    }

    // Checks if futures returned by threads have all completed
    public boolean isDone(List<Future<?>> futures)
    {
        for(Future future: futures)
        {
            if(!future.isDone())
            {
                return false;
            }
        }

        return true;
    }

    //print usage information
    public void printUsage()
    {
        System.out.println("usage: java Download <download directory> [clean]");
        System.out.println("       if clean option given, stop after deleting");
        System.out.println("       download directory and contents.");
        System.exit(0);
    }


    //delete and old downloads directory and create a new one
    //if a download is to be performed
    public void cleanUp(String downloadDir)
    {
        File dir = new File(downloadDir);
        if (dir.exists())
        {
            //perform a recursive delete of the directory and its contents
            deleteDirectory(dir);
        }
        try
        {
            //if not simply deleting the downloads directory, create a new one
            if (cleanOnly == false)
            {
                dir.mkdir();
                if (!dir.exists()) badDirectory();
            }
        } catch (Exception e)
        {
            badDirectory();
        }
    }
   
    //called when program is not able to create downloads directory
    private void badDirectory()
    {
        System.out.println("error: unable to create download directory: " 
                           + downloadDir);
        printUsage(); 
    }

    //perform a recursive delete of the contents of a directory
    private boolean deleteDirectory(File file) 
    {
        //if the file is a directory, delete contents first
        if (file.isDirectory()) 
        {
            //get the files in the directory
            File[] children = file.listFiles();
            for (int i = 0; i < children.length; i++) 
            {
                //call deleteDirectory on each child
                boolean success = deleteDirectory(children[i]);
                if (!success) return false;
            }
        }
        //delete the file or empty directory
        return file.delete();
    }
}
