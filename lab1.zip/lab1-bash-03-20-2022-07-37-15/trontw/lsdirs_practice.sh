#!/usr/bin/env bash

if [[ "$1" != "" ]];then 
  echo "test"
  ls $1|awk '{print $NF}'|sort -r
else
  return 1
fi