input="goodie"
echo "$input"
str1=${input:0:3}
str2=${input:(-3)}
newstr1=${input/#$str1/$str2}
echo "First newstr1 = $newstr1"
newstr2=${newstr1/%$str2/$str1}
echo "$str1 $str2"
echo "$newstr1"
echo "$newstr2"
echo "Combined = $newstr2$newstr1"


