#!/bin/bash

./loggedon.bats
./userIdWnums.bats
./userIdNnums.bats
./capitalize.bats
./countDateNums.bats
./switchLets.bats
./handleCSV.bats
./pppath.bats
./lsdirs.bats
./recdirs.bats
./revline.bats
./convline.bats
