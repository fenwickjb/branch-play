// Author(s): Alex Clarke
// Date:      2022-02-09
// Class:     CS5521
// Name:      Lab 03

// Based on a provided program, all changes have been marked with !!CHANGED!!.

class FileAttributes {
  private String filePath;      // URL
  private String downloadDir;   // Destination download directory
  private String fileName;      // Destination file
  private long downloadAmt;     // Amount downloaded

  // !!CHANGED!! - A place to store the assigned thread.
  private Integer assignedThread; 

  // Constructor.
  FileAttributes(String filePath, String downloadDir) {
    this.downloadDir = downloadDir;
    this.downloadAmt = 0;
    this.filePath = filePath;
    this.fileName = initFileName(filePath);
    this.assignedThread = null;
  }

  // Strip off the piece after the right most / and use that as the filename.
  private String initFileName(String path) {
    String[] tokens = path.split("/");
    int index = tokens.length - 1;
    if (index < 0) return null;
    if (tokens[index] == "") index--;
    if (index < 0) return null;
    return tokens[index];
  }

  // Called by Downloader object to update the current amount downloaded.
  public void updateDownload(long amount) {
    this.downloadAmt += amount;
  }

  // Return the file name.
  public String getFileName() {
    return fileName;
  }

  // Return the url.
  public String getFilePath() {
    return filePath;
  }

  // Return the destination download directory.
  public String getDownloadDir() {
    return downloadDir;
  }

  // Return the downloaded amount.
  public long getDownloadAmount() {
    return downloadAmt;
  }

  // !!CHANGED!! - A setter for the thread.
  public void updateThread(int t) {
    this.assignedThread = t;
  }

  // !!CHANGED!! - A getter for the thread.
  public Integer getThread() {
    return this.assignedThread;
  }
}
