#!/usr/bin/env bash
newline=$(revline_practices.sh)
echo "$newline"|while read -r input;do
    newline=$(echo "$input"|tr -d "\n")
    #newlines=$(echo "$newline"|awk '{print}' ORS=' ')
    echo "$newline"
done