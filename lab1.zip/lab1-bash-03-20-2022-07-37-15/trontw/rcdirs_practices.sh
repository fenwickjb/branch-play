#!/usr/bin/env bash
  path=$(pwd)
  if [[ ("$1" != "") && (-d "$path/$1") && ( ! -f "$path/$1")]];then
    # Capture the parent directory info
    count1=$(find $1/ -mindepth 1 -type d|wc -l)
    dir1="$path/$1"
    echo "$dir1" | while read line;do
        #printf "directory: %s$line, number of subdirectories: %s$count1 \n"
        echo "directory: $line, number of subdirectories: $count1"
        #if [[ "$count1" == 0 ]];then
        #    exit 1 
        #fi
    done
    if [[ "$count1" != 0 ]];then
        # First capture the directories
        these_dir=$(find $1/ -mindepth 1 -type d)
        # Read through the captured directories
        echo "$these_dir" | while read -r input;do
            for d in $input/ ; do
                #echo "Inside the for loop and the directory is $d"
                count=$(find $input/ -mindepth 1 -type d|wc -l)
                dir="$path/$input"
                echo "$dir" | while read line;do
                    #printf "directory:  %s$line, number of subdirectories: %s$count \n"
                    echo "directory: $line, number of subdirectories: $count"
                done
            done
        done
    else
        echo "No subdirectories found"
        return 0
    fi
    else
        return 1
  fi