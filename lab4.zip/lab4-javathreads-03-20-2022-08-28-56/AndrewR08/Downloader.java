import java.io.*;
import java.net.URL;

//Implements Runnable so that each Downloader object will be a thread executed by the Executor
// for the thread pool
class Downloader implements Runnable
{
    //Method to get the thread Name used in the printUpdate method
    public static String threadName()
    {
	return Thread.currentThread().getName();
    }

    //File Manager provides the downloader with the
    //attributes of the next file to download
    private FileManager fm;
    //download file chunkSize bytes at a time
    private final int chunkSize = 1024;

    //constructor
    Downloader(FileManager fm)
    {
       this.fm = fm;
    }

    //Run method implemented to use the runnable interface so that when a thread is executed
    //for a Downloader object, this method is called
    @Override
    public void run()
    {
	//print out the current running thread
	//System.out.println("Thread " + Thread.currentThread().getName() + " is running");
	try {
		doDownloads();
	}
	catch (Exception e) {
		System.out.println("Exception " + e + " caught");
    	}
    }


    //get the attributes of files to download and download them.
    public void doDownloads()
    {
       //get attributes of next file from File Manager
       FileAttributes fileAttrs = fm.getNextFile();
       while (fileAttrs != null)
       {
           //go the download
           downloadFile(fileAttrs);
           fileAttrs = fm.getNextFile();
       }
    }
    
    public synchronized void downloadFile(FileAttributes fileAttrs)
    {
        //attributes of the file include the url, the filename to be used
        //for the destination, and the download directory 
        String fileURL = fileAttrs.getFilePath();
        String fileName = fileAttrs.getFileName();
        String downloadDir = fileAttrs.getDownloadDir();
        String destination = downloadDir + "/" + fileName;

        //download the object at the URL
        //store it in the destination
        try (BufferedInputStream in = new 
            BufferedInputStream(new URL(fileURL).openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(destination)) 
        {
            //download in chunks of chunkSize bytes at a time
            byte dataBuffer[] = new byte[chunkSize];
            int bytesRead;
            int iterations = 0;
	    while ((bytesRead = in.read(dataBuffer, 0, chunkSize)) != -1) 
            {
                //write the chunk read to the destination
                fileOutputStream.write(dataBuffer, 0, bytesRead);
                //update the downloaded amount that is maintained in the File Attributes
                fileAttrs.updateDownload(bytesRead);
                //update the total download amount that is maintained by the File Manager
                fm.updateTotalDownload(bytesRead);
            	if (iterations % 10000 == 0) {
			fm.printUpdate();
		}
		iterations++;
	    }
        } catch (IOException e) 
        {
            System.out.println("Unable to read " + fileURL);
        }
    }
}
