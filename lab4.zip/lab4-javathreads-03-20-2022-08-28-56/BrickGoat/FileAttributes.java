
class FileAttributes {
    private String filePath; // URL
    private String downloadDir; // destination download directory
    private String fileName; // destination file
    private String threadName;
    private long downloadAmt; // amount downloaded
    // Doesn't need synchronized methods, but could modify code so multiple threads
    // work on one download
    private Object lock1 = new Object();
    private Object lock2 = new Object();

    // constructor
    FileAttributes(String filePath, String downloadDir) {
        this.downloadDir = downloadDir;
        this.downloadAmt = 0;
        this.filePath = filePath;
        this.fileName = initFileName(filePath);
        this.threadName = "No thread";
    }

    // strip off the piece after the right most / and use that
    // as the filename
    private String initFileName(String path) {
        String[] tokens = path.split("/");
        int index = tokens.length - 1;
        if (index < 0)
            return null;
        if (tokens[index] == "")
            index--;
        if (index < 0)
            return null;
        return tokens[index];
    }

    // called by Downloader object to update the current
    // amount downloaded
    public void updateDownload(long amount) {
        synchronized (lock1) {
            this.downloadAmt += amount;
        }
    }

    // return the file name
    public String getFileName() {
        return fileName;
    }

    // return the url
    public String getFilePath() {
        return filePath;
    }

    // return the destination download directory
    public String getDownloadDir() {
        return downloadDir;
    }

    public String getThreadName() {
        return threadName;
    }

    public void setThreadName(String threadName) {
        synchronized (lock2) {
            this.threadName = threadName;
        }
    }

    // return the downloaded amount
    public long getDownloadAmount() {
        return downloadAmt;
    }
}
