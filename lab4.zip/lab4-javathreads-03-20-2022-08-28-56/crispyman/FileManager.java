import java.util.concurrent.atomic.AtomicInteger;

class FileManager
{
    //These are the objects to download
    private String[] urls = 
    {
        "https://alvinalexander.com/java/java-string-array-reference-java-5-for-loop-syntax",
        "https://www.crimesceneinvestigatoredu.org/what-is-forensic-science/",
        "http://www.stewartonbibleschool.org.uk/bible/text/levit.txt",
        "http://shakespeare.mit.edu/richardiii/full.html",
        "https://www.tutorialspoint.com/java/java_multithreading.htm",
        "http://textfiles.com/etext/AUTHORS/SHAKESPEARE/shakespeare-coriolanus-24.txt",
        "https://archive.org/stream/warandpeace030164mbp/warandpeace030164mbp_djvu.txt",
	"https://covid.cdc.gov/covid-data-tracker/",
        "https://www.pcgamer.com/best-gaming-pc/",
        "http://textfiles.com/etext/AUTHORS/SHAKESPEARE/shakespeare-tragedy-58.txt",
        "http://www.stewartonbibleschool.org.uk/bible/text/genesis.txt",
        "http://triggs.djvu.org/djvu-editions.com/SHAKESPEARE/SONNETS/Download.pdf",
        "https://www.folgerdigitaltexts.org/download/pdf/Son.pdf",
        "http://shakespeare.mit.edu/merry_wives/full.html", 
    };

    private int next;                      //all files up to next have already been downloaded
    //implemented as AtomicInteger as a faster way to ensure
    private AtomicInteger totalDownload;             //total amount downloaded (all files)
    private FileAttributes[] fileAttrsArr; //attributes of each file

    //create a FileManager object
    //downloadDir is the destination directory for the downloads
    FileManager(String downLoadDir)
    {
        int i;
        int size = urls.length;
        //create a FileAttributes object for each file
        fileAttrsArr = new FileAttributes[size];
        for (i = 0; i < size; i++)
           fileAttrsArr[i] = new FileAttributes(urls[i], downLoadDir);
        //next is the next file to download (initialize to 0)
        next = 0; 
        //totalDownload is the total amount downloaded (all files)
        totalDownload = new AtomicInteger(0);
    }

    //return the attributes of the next file to download or null
    //if all files have been downloaded
    public FileAttributes getNextFile()
    {
        if (next == fileAttrsArr.length) return null;
        next++;
        return (fileAttrsArr[next - 1]);
    }

    //update the total download amount (all files)
    public void updateTotalDownload(int amount)
    {
        // add amount to totalDownload, since its a AtomicInteger you can't just use +=
        // although I don't see a technical reason they couldn't overload the += operator with it
        // Oh also addAndGet on a AtomicInteger is an atomic operation
        totalDownload.addAndGet(amount);
    }

    //print an update of how much of each file has been downloaded
    public boolean printUpdate()
    {
        // will get updated to false if there are any threads that haven't finished
        boolean finished = true;
        int i;
        //clears the terminal
        System.out.print("\033[H\033[2J");
        //iterates over each file to check if it's done
        for (i = 0; i < fileAttrsArr.length; i++)
        {
            // prints thread, file and file size if done and updates file flag so that it doesn't get printed again.
            if (fileAttrsArr[i].isDone() >= 0) {
                System.out.println("(Thread"+ fileAttrsArr[i].isDone() + ") " + fileAttrsArr[i].getFileName() + ": " +
                        fileAttrsArr[i].getDownloadAmount());
            }
            // checks to see if any threads aren't done and updates finished flag if not
            // also prints out the file with the No thread tag
            else if (fileAttrsArr[i].isDone() == -1) {
                finished = false;
                System.out.println("(No thread) " + fileAttrsArr[i].getFileName() + ": " +
                        fileAttrsArr[i].getDownloadAmount());
            }
        }
        // An atomic read of total-download so no need to synchronize
        System.out.println("Total download: " + totalDownload.get());

        return finished;
    }

    // a helper to make spawning threads easier in Downloader
    public int length(){
        return urls.length;
    }
}
