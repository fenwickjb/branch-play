#!/usr/bin/env bash
rm newlist
# Check to see if there is no input first
    input=$1
    if [[ ("$input" != "") && ("$input" == *.csv)]];then 
    # Replace commas with newline characters
    cat "$input" | while read -r line;do  
      newline=$(echo "$line" | tr "," "\n" |awk 'BEGIN{i=1} /.*/{printf "%d) % s\n",i,$1; i++}')
      echo "$newline" >> newlist
    done    
  else
    echo "Either no input or wrong extension used."
    return 1
  fi
awk -v RS="" '{print}' newlist
#return 0   
