#!/bin/bash
# 
# shell script to print blinking hello world
#
# \033[5m escape sequence turns the blinking on
# \033[0m escape sequence resume to normal
# # -e option enables the \ sequence to be treated as an escape
#
echo -e "\033[5m Hello World"

echo -e "\033[0m Goodbye"
